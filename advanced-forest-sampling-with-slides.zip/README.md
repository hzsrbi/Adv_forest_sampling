# Advanced Forest Sampling | روش‌های پیشرفته نمونه‌برداری در جنگل

Bilingual static course website for the PhD course at Tarbiat Modares University. Includes **14 original lecture PDFs** in `lectures/`.

## Publish on GitHub Pages
1. Create a **public** repository named `advanced-forest-sampling` on GitHub.
2. Upload **the contents of this folder** (including `index.html`, `style.css`, `script.js`, and the entire `lectures` directory) to the repository root. Do not upload only the ZIP.
3. Open **Settings → Pages → Build and deployment**; select **Deploy from a branch**, branch `main`, folder `/ (root)` and save.
4. Your site should appear at `https://YOUR-USERNAME.github.io/advanced-forest-sampling/` after deployment.

## Update lectures
Replace the matching `lectures/session-XX.pdf` file to update slides. For a new session, add the PDF and a matching entry in the `lectures` array near the start of `script.js`.

## Notes
- Language switcher supports English and Persian (RTL); lecture PDF content is unchanged.
- All slides are published publicly when committed to a public repository. Verify distribution rights before publishing.
- Browser PDF preview may vary; the Open PDF and Download links are alternatives.
- Requires no build step, dependencies or server-side code. The Persian font is loaded from Google Fonts when internet is available, with local fallback.
